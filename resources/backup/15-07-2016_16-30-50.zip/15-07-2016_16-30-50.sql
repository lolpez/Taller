-- MySQL dump 10.13  Distrib 5.6.21, for Win32 (x86)
--
-- Host: localhost    Database: taller
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `archivo_config`
--

DROP TABLE IF EXISTS `archivo_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `archivo_config` (
  `pkarchivo_config` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  `extension` varchar(10) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pkarchivo_config`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archivo_config`
--

LOCK TABLES `archivo_config` WRITE;
/*!40000 ALTER TABLE `archivo_config` DISABLE KEYS */;
INSERT INTO `archivo_config` VALUES (1,'Documento formato portable PDF','fa fa-file-pdf-o fa-fw','pdf',1),(2,'Documentos word','fa fa-file-word-o fa-fw','docx',1),(3,'Archivos de audio mp3','fa fa-file-audio-o fa-fw','mp3',1),(4,'Archivos de video','fa fa-file-movie-o fa-fw','mp4',1);
/*!40000 ALTER TABLE `archivo_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `pkarea` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `fkarea_padre` int(11) NOT NULL,
  PRIMARY KEY (`pkarea`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (100,'General','GRAL',1,100),(101,'Desarrollo de software','DSW',1,100),(102,'Redes','RDS',1,100),(103,'Recursos humanos','RRHH',1,100),(104,'Ventas','VNT',1,100),(105,'WUT','sin nombre',0,100),(106,'Otro sin nombre','NOPE',0,100);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_flujo`
--

DROP TABLE IF EXISTS `area_flujo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_flujo` (
  `pkarea_flujo` int(11) NOT NULL AUTO_INCREMENT,
  `flujo` text NOT NULL,
  `fkarea` int(11) NOT NULL,
  PRIMARY KEY (`pkarea_flujo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_flujo`
--

LOCK TABLES `area_flujo` WRITE;
/*!40000 ALTER TABLE `area_flujo` DISABLE KEYS */;
INSERT INTO `area_flujo` VALUES (1,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":2,\"loc\":\"141.04952779281646 -52.03016516589456\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"280.54772736965435 101.55132821597856\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"441.7645219701915 -47.376180517959014\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"665.0344452098692 -47.376180517958986\",\"text\":\"Emisor\"}],\"linkDataArray\":[{\"from\":2,\"to\":3,\"id\":-1,\"points\":[224.9853999593,-13.339023409553,223.39126310091,37.231877183484,259.07181206841,72.91242615099,318.75325896363,101.83328668544],\"text\":\"ela\",\"pkestado_documento\":\"1\",\"nombre_estado_documento\":\"Elaborado\"},{\"from\":3,\"to\":4,\"id\":-2,\"points\":[417.35311865269,101.89868355759,454.53916728171,89.977036526754,487.11705981725,49.642502911313,503.78815487543,-8.7040299811109],\"text\":\"rev\",\"pkestado_documento\":\"2\",\"nombre_estado_documento\":\"Revisado\"},{\"from\":4,\"to\":5,\"id\":-3,\"points\":[513.2634510551,-47.36604677174,526.70364239461,-113.78169510209,684.13574324653,-113.24695976643,697.62202313227,-47.366022455549],\"text\":\"apr\",\"pkestado_documento\":\"3\",\"nombre_estado_documento\":\"Aprobado\"}]}',100),(2,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":6,\"loc\":\"600 100\",\"text\":\"Emisor\"},{\"id\":8,\"loc\":\"800 100\",\"text\":\"Director de area\"}],\"linkDataArray\":[]}',101),(3,' {\"class\": \"go.GraphLinksModel\",\"nodeKeyProperty\": \"id\",\"linkKeyProperty\": \"id\",\"nodeDataArray\": [{\"id\":1, \"loc\":\"0 100\", \"text\":\"Administrador\"},{\"id\":2, \"loc\":\"200 100\", \"text\":\"Responsable de area\"},{\"id\":3, \"loc\":\"400 100\", \"text\":\"Supervisor de area\"},{\"id\":6, \"loc\":\"600 100\", \"text\":\"Emisor\"},{\"id\":8, \"loc\":\"800 100\", \"text\":\"Director de area\"}]}     ',101),(4,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',102),(5,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',103),(6,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',104),(7,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',105),(8,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',106);
/*!40000 ALTER TABLE `area_flujo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendario`
--

DROP TABLE IF EXISTS `calendario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendario` (
  `fecha` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendario`
--

LOCK TABLES `calendario` WRITE;
/*!40000 ALTER TABLE `calendario` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargo` (
  `pkcargo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `estado` int(11) DEFAULT '1',
  PRIMARY KEY (`pkcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'Administrador','Encargado de la administracion del sistema',1),(2,'Responsable de area','encargado de elaboracion de documentos',1),(3,'Supervisor de area','encargado de la revision de documentos elaborados',1),(4,'Director de area','Encargado de aprobar documentos',1),(5,'Emisor','encargado de emitir los documentos',1);
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_documento`
--

DROP TABLE IF EXISTS `estado_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_documento` (
  `pkestado_documento` int(11) NOT NULL AUTO_INCREMENT,
  `nomenglatura` varchar(10) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `color` varchar(7) NOT NULL,
  PRIMARY KEY (`pkestado_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_documento`
--

LOCK TABLES `estado_documento` WRITE;
/*!40000 ALTER TABLE `estado_documento` DISABLE KEYS */;
INSERT INTO `estado_documento` VALUES (1,'ela','Elaborado','El documento fue creado y esta listo para ser revisado','#ddff00'),(2,'rev','Revisado','El documento fue revisado y esta listo para ser aprobado','#0033ff'),(3,'apr','Aprobado','El documento fue aprobado y esta listo para ser emitido','#047a00'),(4,'emi','Emitido','El documento fue emitido','#c400ff'),(5,'rec','Rechazado','El documento fue rechazado','#d10000'),(6,'dev','Devuelto','El documento fue devuelto','#ffcc00');
/*!40000 ALTER TABLE `estado_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `pkmenu` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  PRIMARY KEY (`pkmenu`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Gestion documentos','fa fa-folder fa-fw fa-2x'),(2,'Configuracion','fa fa-cog fa-fw fa-2x'),(3,'Seguridad','fa fa-lock fa-fw fa-2x'),(4,'Reportes','fa fa-bar-chart fa-fw fa-2x');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_detalle`
--

DROP TABLE IF EXISTS `menu_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_detalle` (
  `pkmenu_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  `controlador` varchar(30) NOT NULL,
  `fkmenu` int(11) NOT NULL,
  PRIMARY KEY (`pkmenu_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_detalle`
--

LOCK TABLES `menu_detalle` WRITE;
/*!40000 ALTER TABLE `menu_detalle` DISABLE KEYS */;
INSERT INTO `menu_detalle` VALUES (1,'Documento','fa fa-file fa-fw','documento',1),(2,'Plantilla','fa fa-file-text fa-fw','plantilla',1),(4,'Bitacora','fa fa-desktop fa-fw','bitacora',4),(5,'Usuario','fa fa-user fa-fw','usuario',3),(6,'Cargo','fa fa-briefcase fa-fw ','cargo',2),(7,'Permisos','fa fa-ban fa-fw','privilegio',3),(8,'Calendario','fa fa-calendar fa-fw','calendario',3),(9,'Archivos permitidos','fa fa-file-o fa-fw','archivo_config',3),(10,'Area','fa fa-sitemap fa-fw','area',2),(11,'Tipo documento','fa fa-cubes fa-fw','tipo_documento',2),(12,'Copia de seguridad','fa fa-database fa-fw','backup',3),(14,'Estado de documento','fa fa-clock-o fa-fw','estado_documento',2);
/*!40000 ALTER TABLE `menu_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilegio`
--

DROP TABLE IF EXISTS `privilegio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilegio` (
  `fkcargo` int(11) NOT NULL,
  `fkmenu_detalle` int(11) NOT NULL,
  PRIMARY KEY (`fkcargo`,`fkmenu_detalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilegio`
--

LOCK TABLES `privilegio` WRITE;
/*!40000 ALTER TABLE `privilegio` DISABLE KEYS */;
INSERT INTO `privilegio` VALUES (1,1),(1,2),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,14),(2,1),(2,2);
/*!40000 ALTER TABLE `privilegio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_documento`
--

DROP TABLE IF EXISTS `tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_documento` (
  `pktipo_documento` int(11) NOT NULL AUTO_INCREMENT,
  `sigla` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pktipo_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_documento`
--

LOCK TABLES `tipo_documento` WRITE;
/*!40000 ALTER TABLE `tipo_documento` DISABLE KEYS */;
INSERT INTO `tipo_documento` VALUES (1,'PLAN','plan de negocio',1),(2,'PRFL','perfil de proyecto',1);
/*!40000 ALTER TABLE `tipo_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `pkusuario` int(11) NOT NULL AUTO_INCREMENT,
  `ci` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `archivo` varchar(30) NOT NULL,
  `fkarea` int(11) NOT NULL,
  `fkcargo` int(11) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pkusuario`),
  KEY `fkcargo` (`fkcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (2,0,'luis daniel','admin@hotmail.com',78888777,'luis.crip',100,1,1),(3,1,'alejandro mollejas','alejandro@hotmail.com',123456,'alejandro.crip',100,2,1),(4,123,'el supervisor','jose@hotmail.com',123,'jose.crip',100,3,1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-15 16:30:53
