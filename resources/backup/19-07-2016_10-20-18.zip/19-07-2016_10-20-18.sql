-- MySQL dump 10.13  Distrib 5.6.21, for Win32 (x86)
--
-- Host: localhost    Database: taller
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `archivo_config`
--

DROP TABLE IF EXISTS `archivo_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `archivo_config` (
  `pkarchivo_config` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  `extension` varchar(10) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pkarchivo_config`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archivo_config`
--

LOCK TABLES `archivo_config` WRITE;
/*!40000 ALTER TABLE `archivo_config` DISABLE KEYS */;
INSERT INTO `archivo_config` VALUES (1,'Documento formato portable PDF','fa fa-file-pdf-o fa-fw','pdf',1),(2,'Documentos word','fa fa-file-word-o fa-fw','docx',1),(3,'Archivos de audio mp3','fa fa-file-audio-o fa-fw','mp3',1),(4,'Archivos de video','fa fa-file-movie-o fa-fw','mp4',1);
/*!40000 ALTER TABLE `archivo_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `pkarea` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `fkarea_padre` int(11) NOT NULL,
  PRIMARY KEY (`pkarea`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (100,'General','GRAL',1,100),(101,'Desarrollo de software','DSW',1,100),(102,'Redes','RDS',1,100),(103,'Recursos humanos','RRHH',1,100),(104,'Ventas','VNT',1,100),(105,'WUT','sin nombre',0,100),(106,'Otro sin nombre','NOPE',0,100);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_flujo`
--

DROP TABLE IF EXISTS `area_flujo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_flujo` (
  `pkarea_flujo` int(11) NOT NULL AUTO_INCREMENT,
  `flujo` text NOT NULL,
  `fkarea` int(11) NOT NULL,
  PRIMARY KEY (`pkarea_flujo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_flujo`
--

LOCK TABLES `area_flujo` WRITE;
/*!40000 ALTER TABLE `area_flujo` DISABLE KEYS */;
INSERT INTO `area_flujo` VALUES (1,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"16 10.000000000000014\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"14.000000000000028 122.00000000000001\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"235.00000000000006 62.000000000000014\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"432 62.000000000000014\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"457.0000000000001 199\",\"text\":\"Emisor\"}],\"linkDataArray\":[{\"from\":1,\"to\":3,\"id\":-1,\"points\":[140.09077500514,32.425843209247,175.44762401983,34.336123414006,210.29537968574,42.049073122287,263.76364491409,62.318307570242],\"text\":\"ela\",\"pkestado_documento\":\"1\",\"nombre_estado_documento\":\"Elaborado\"},{\"from\":2,\"to\":3,\"id\":-2,\"points\":[139.53172342864,122.28919619961,188.57292713882,99.487434837017,215.22183095232,92.015779562205,235.57134139539,89.784764595546],\"text\":\"ela\",\"pkestado_documento\":\"1\",\"nombre_estado_documento\":\"Elaborado\"},{\"from\":3,\"to\":4,\"id\":-3,\"points\":[341.42212510996,100.46744742682,383,128,426,128,469.41518871108,100.45922475817],\"text\":\"rev\",\"pkestado_documento\":\"2\",\"nombre_estado_documento\":\"Revisado\"},{\"from\":4,\"to\":5,\"id\":-4,\"points\":[502.45024937501,100.68584491525,507.84080260659,140.19767871162,506.63210757886,171.11753615036,499.11087459585,199.01952418526],\"text\":\"apr\",\"pkestado_documento\":\"3\",\"nombre_estado_documento\":\"Aprobado\"},{\"from\":5,\"to\":5,\"id\":-7,\"points\":[504.72969392273,237.62387976681,556,326,437,321,482.92356578433,237.62934323914],\"text\":\"emi\",\"pkestado_documento\":\"4\",\"nombre_estado_documento\":\"Emitido\"},{\"from\":3,\"to\":1,\"id\":-6,\"points\":[299.62118075148,62.084811706699,264,9,216,-11,133.85878929624,13.022767782602],\"text\":\"rec\",\"pkestado_documento\":\"5\",\"nombre_estado_documento\":\"Rechazado\"}]}',100),(2,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"-1.628894626777445 -51.48720029030213\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"-18.271879988177233 101.62889462677748\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[{\"from\":2,\"to\":3,\"id\":-1,\"points\":[150.27026643809,112.62034115098,233.81630249007,104.31089078511,316.87646843612,103.9819204261,400.28829017308,111.95806155229],\"text\":\"ela\",\"pkestado_documento\":\"1\",\"nombre_estado_documento\":\"Elaborado\"},{\"from\":1,\"to\":3,\"id\":-2,\"points\":[118.17219066026,-17.268179534947,221.54760232501,9.3533386541298,326.09612450122,47.321849402189,437.4659957446,100.28526411553],\"text\":\"ela\",\"pkestado_documento\":\"1\",\"nombre_estado_documento\":\"Elaborado\"},{\"from\":3,\"to\":4,\"id\":-3,\"points\":[494.4571107961,100.12461286403,542.42191071689,45.609049549768,604.31990653443,47.237944176546,650.69170158921,100.12405163711],\"text\":\"rev\",\"pkestado_documento\":\"2\",\"nombre_estado_documento\":\"Revisado\"},{\"from\":4,\"to\":5,\"id\":-4,\"points\":[685.32303954219,100.13300365569,729.74479279629,52.124628056878,786.7561047335,66.784679697875,818.34983751654,100.13700622593],\"text\":\"apr\",\"pkestado_documento\":\"3\",\"nombre_estado_documento\":\"Aprobado\"},{\"from\":5,\"to\":5,\"id\":-5,\"points\":[847.67626207598,138.62440269512,860.67626207598,161.14106319352,812.41512791725,161.14106319352,825.41512791725,138.62440269512],\"text\":\"emi\",\"pkestado_documento\":\"4\",\"nombre_estado_documento\":\"Emitido\"}]}',101),(4,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',102),(5,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',103),(6,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',104),(7,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',105),(8,'{\"class\":\"go.GraphLinksModel\",\"nodeKeyProperty\":\"id\",\"linkKeyProperty\":\"id\",\"nodeDataArray\":[{\"id\":1,\"loc\":\"0 100\",\"text\":\"Administrador\"},{\"id\":2,\"loc\":\"200 100\",\"text\":\"Responsable de area\"},{\"id\":3,\"loc\":\"400 100\",\"text\":\"Supervisor de area\"},{\"id\":4,\"loc\":\"600 100\",\"text\":\"Director de area\"},{\"id\":5,\"loc\":\"800 100\",\"text\":\"Emisor\"}],\"linkDataArray\":[]}',106);
/*!40000 ALTER TABLE `area_flujo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avance`
--

DROP TABLE IF EXISTS `avance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avance` (
  `pkavance` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` varchar(10) NOT NULL,
  `hora` varchar(10) NOT NULL,
  `fkusuario` int(11) NOT NULL,
  `fkdocumento` int(11) NOT NULL,
  `fkestado_documento` int(11) NOT NULL,
  PRIMARY KEY (`pkavance`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avance`
--

LOCK TABLES `avance` WRITE;
/*!40000 ALTER TABLE `avance` DISABLE KEYS */;
INSERT INTO `avance` VALUES (1,'as','as',1,1,1);
/*!40000 ALTER TABLE `avance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendario`
--

DROP TABLE IF EXISTS `calendario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendario` (
  `fecha` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendario`
--

LOCK TABLES `calendario` WRITE;
/*!40000 ALTER TABLE `calendario` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargo` (
  `pkcargo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `estado` int(11) DEFAULT '1',
  PRIMARY KEY (`pkcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'Administrador','Encargado de la administracion del sistema',1),(2,'Responsable de area','encargado de elaboracion de documentos',1),(3,'Supervisor de area','encargado de la revision de documentos elaborados',1),(4,'Director de area','Encargado de aprobar documentos',1),(5,'Emisor','encargado de emitir los documentos',1);
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emision`
--

DROP TABLE IF EXISTS `emision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emision` (
  `pkemision` int(11) NOT NULL AUTO_INCREMENT,
  `fkusuario` int(11) NOT NULL,
  `fkdocumento` varchar(50) NOT NULL,
  `fkarea` int(11) NOT NULL,
  PRIMARY KEY (`pkemision`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emision`
--

LOCK TABLES `emision` WRITE;
/*!40000 ALTER TABLE `emision` DISABLE KEYS */;
/*!40000 ALTER TABLE `emision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_documento`
--

DROP TABLE IF EXISTS `estado_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado_documento` (
  `pkestado_documento` int(11) NOT NULL AUTO_INCREMENT,
  `nomenglatura` varchar(10) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `color` varchar(7) NOT NULL,
  PRIMARY KEY (`pkestado_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_documento`
--

LOCK TABLES `estado_documento` WRITE;
/*!40000 ALTER TABLE `estado_documento` DISABLE KEYS */;
INSERT INTO `estado_documento` VALUES (1,'ela','Elaborado','El documento fue creado y esta listo para ser revisado','#ddff00'),(2,'rev','Revisado','El documento fue revisado y esta listo para ser aprobado','#0033ff'),(3,'apr','Aprobado','El documento fue aprobado y esta listo para ser emitido','#047a00'),(4,'emi','Emitido','El documento fue emitido','#c400ff'),(5,'rec','Rechazado','El documento fue rechazado','#d10000'),(6,'dev','Devuelto','El documento fue devuelto','#ffcc00');
/*!40000 ALTER TABLE `estado_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `pkmenu` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  PRIMARY KEY (`pkmenu`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Gestion documentos','fa fa-folder fa-fw fa-2x'),(2,'Configuracion','fa fa-cog fa-fw fa-2x'),(3,'Seguridad','fa fa-lock fa-fw fa-2x'),(4,'Reportes','fa fa-bar-chart fa-fw fa-2x');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_detalle`
--

DROP TABLE IF EXISTS `menu_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_detalle` (
  `pkmenu_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  `controlador` varchar(30) NOT NULL,
  `fkmenu` int(11) NOT NULL,
  PRIMARY KEY (`pkmenu_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_detalle`
--

LOCK TABLES `menu_detalle` WRITE;
/*!40000 ALTER TABLE `menu_detalle` DISABLE KEYS */;
INSERT INTO `menu_detalle` VALUES (1,'Documento','fa fa-file fa-fw','documento',1),(2,'Plantilla','fa fa-file-text fa-fw','plantilla',1),(4,'Bitacora','fa fa-desktop fa-fw','bitacora',4),(5,'Usuario','fa fa-user fa-fw','usuario',3),(6,'Cargo','fa fa-briefcase fa-fw ','cargo',2),(7,'Permisos','fa fa-ban fa-fw','privilegio',3),(8,'Calendario','fa fa-calendar fa-fw','calendario',3),(9,'Archivos permitidos','fa fa-file-o fa-fw','archivo_config',3),(10,'Area','fa fa-sitemap fa-fw','area',2),(11,'Tipo documento','fa fa-cubes fa-fw','tipo_documento',2),(12,'Copia de seguridad','fa fa-database fa-fw','backup',3),(14,'Estado de documento','fa fa-clock-o fa-fw','estado_documento',2);
/*!40000 ALTER TABLE `menu_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacion`
--

DROP TABLE IF EXISTS `notificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificacion` (
  `pknotificacion` int(11) NOT NULL AUTO_INCREMENT,
  `fkavance` int(11) NOT NULL,
  `fkusuario_destino` int(11) NOT NULL,
  `terminado` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pknotificacion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacion`
--

LOCK TABLES `notificacion` WRITE;
/*!40000 ALTER TABLE `notificacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `notificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilegio`
--

DROP TABLE IF EXISTS `privilegio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilegio` (
  `fkcargo` int(11) NOT NULL,
  `fkmenu_detalle` int(11) NOT NULL,
  PRIMARY KEY (`fkcargo`,`fkmenu_detalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilegio`
--

LOCK TABLES `privilegio` WRITE;
/*!40000 ALTER TABLE `privilegio` DISABLE KEYS */;
INSERT INTO `privilegio` VALUES (1,1),(1,2),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,14),(2,1),(2,2),(3,1),(3,2),(4,1),(4,2),(5,1);
/*!40000 ALTER TABLE `privilegio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_documento`
--

DROP TABLE IF EXISTS `tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_documento` (
  `pktipo_documento` int(11) NOT NULL AUTO_INCREMENT,
  `sigla` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pktipo_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_documento`
--

LOCK TABLES `tipo_documento` WRITE;
/*!40000 ALTER TABLE `tipo_documento` DISABLE KEYS */;
INSERT INTO `tipo_documento` VALUES (1,'PLAN','plan de negocio',1),(2,'PRFL','perfil de proyecto',1);
/*!40000 ALTER TABLE `tipo_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `pkusuario` int(11) NOT NULL AUTO_INCREMENT,
  `ci` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `archivo` varchar(30) NOT NULL,
  `fkarea` int(11) NOT NULL,
  `fkcargo` int(11) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pkusuario`),
  KEY `fkcargo` (`fkcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (2,0,'luis daniel','admin@hotmail.com',78888777,'luis.crip',100,1,1),(3,1,'alejandro mollejas','alejandro@hotmail.com',123456,'alejandro.crip',101,2,1),(4,123,'jose','jose@hotmail.com',123,'jose.crip',100,3,1),(5,456,'miguel','miguel@hotmail.com',456,'miguel.crip',100,4,1),(6,987,'lenka','ramirez@hotmail.com',987,'lenka.crip',100,5,1),(7,1234,'mauro','mauro@hotmail.com',123456,'mauro.crip',101,3,1),(8,1456,'ranulfo','ranulfo@hotmail.com',123456,'ranulfo.crip',101,4,1),(9,1678,'gladys','gladys@hotmail.com',123456,'gladys.crip',101,5,1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-19 10:20:23
