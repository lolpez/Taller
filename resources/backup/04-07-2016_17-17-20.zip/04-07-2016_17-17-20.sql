-- MySQL dump 10.13  Distrib 5.6.21, for Win32 (x86)
--
-- Host: localhost    Database: taller
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `archivo_config`
--

DROP TABLE IF EXISTS `archivo_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `archivo_config` (
  `pkarchivo_config` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  `extencion` varchar(10) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pkarchivo_config`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archivo_config`
--

LOCK TABLES `archivo_config` WRITE;
/*!40000 ALTER TABLE `archivo_config` DISABLE KEYS */;
INSERT INTO `archivo_config` VALUES (1,'Documento formato portable PDF','fa fa-file-pdf-o fa-fw','pdf',1),(2,'Documentos word','fa fa-file-word-o fa-fw','docx',1),(3,'Archivos de audio mp3','fa fa-file-audio-o fa-fw','.mp3',1),(4,'Archivos de video','fa fa-file-movie-o fa-fw','.mp4',0);
/*!40000 ALTER TABLE `archivo_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `pkarea` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `fkarea_padre` int(11) NOT NULL,
  PRIMARY KEY (`pkarea`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (100,'General','GRAL',1,100),(101,'Desarrollo de saftwere','DSW',1,100),(102,'Redes','RDS',1,100),(107,'Recursos humanos','RRHH',1,100),(109,'Ventas','VNT',1,100);
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora` (
  `pkbitacora` int(11) NOT NULL AUTO_INCREMENT,
  `fkusuario` int(11) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `fecha` varchar(10) NOT NULL,
  `hora` varchar(10) NOT NULL,
  PRIMARY KEY (`pkbitacora`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,2,'Inicio de sesion','27/05/2016','02:43:06'),(2,2,'Cierre de sesion','27/05/2016','02:53:48'),(3,2,'Inicio de sesion','27/05/2016','02:54:45'),(4,2,'edito su perfil de usuario','27/05/2016','03:06:53'),(5,2,'Cierre de sesion','27/05/2016','03:06:57'),(6,2,'Inicio de sesion','27/05/2016','03:07:06'),(7,2,'Cierre de sesion','27/05/2016','03:07:10'),(8,2,'Inicio de sesion','27/05/2016','03:07:14'),(9,2,'se modifico el usuario luis daniel','27/05/2016','03:07:31'),(10,2,'Cierre de sesion','27/05/2016','03:22:58'),(11,2,'Inicio de sesion','27/05/2016','03:23:29'),(12,2,'Inicio de sesion','27/05/2016','03:25:50'),(13,2,'Cierre de sesion','27/05/2016','03:34:09'),(14,2,'Inicio de sesion','27/05/2016','03:35:43'),(15,2,'se modifico los permisos para el cargo Administrador','27/05/2016','03:50:00'),(16,2,'se agrego un nuevo tipo de archivo que el sistema permitira (.mp3)','27/05/2016','05:07:20'),(17,2,'se agrego un nuevo tipo de archivo que el sistema permitira (.mp3)','27/05/2016','05:08:52'),(18,2,'se agrego un nuevo tipo de archivo que el sistema permitira (.mp3)','27/05/2016','05:15:00'),(19,2,'se agrego un nuevo tipo de archivo que el sistema permitira (.mp4)','27/05/2016','05:19:35'),(20,2,'se dio de baja el cargo ','27/05/2016','05:20:19'),(21,2,'se dio de baja el cargo ','27/05/2016','05:21:30'),(22,2,'se dio de baja el tipo de archivo permitido por el sistema Archivos de video','27/05/2016','05:22:13'),(23,2,'Inicio de sesion','28/05/2016','09:29:16'),(24,2,'Cierre de sesion','28/05/2016','09:29:20'),(25,2,'Inicio de sesion','28/05/2016','09:29:47'),(26,2,'Cierre de sesion','28/05/2016','09:29:51'),(27,2,'Inicio de sesion','28/05/2016','09:34:06'),(28,2,'Cierre de sesion','28/05/2016','09:34:11'),(29,2,'Inicio de sesion','28/05/2016','09:34:31'),(30,2,'Cierre de sesion','28/05/2016','09:34:37'),(31,2,'Inicio de sesion','28/05/2016','09:51:56'),(32,2,'Cierre de sesion','28/05/2016','09:51:59'),(33,2,'Inicio de sesion','28/05/2016','10:02:21'),(34,2,'Cierre de sesion','28/05/2016','10:02:24'),(35,2,'Inicio de sesion','28/05/2016','10:03:34'),(36,2,'se modifico los permisos para el cargo Responsable de area','28/05/2016','10:03:50'),(37,2,'se modifico el usuario alejandro mollejas','28/05/2016','10:04:00'),(38,2,'Cierre de sesion','28/05/2016','10:04:03'),(39,3,'Inicio de sesion','28/05/2016','10:04:07'),(40,3,'Cierre de sesion','28/05/2016','10:15:25'),(41,2,'Inicio de sesion','28/05/2016','10:15:28'),(42,2,'se modifico los permisos para el cargo Responsable de area','28/05/2016','10:15:39'),(43,2,'Cierre de sesion','28/05/2016','10:15:42'),(44,3,'Inicio de sesion','28/05/2016','10:15:46'),(45,3,'Cierre de sesion','28/05/2016','10:28:35'),(46,3,'Inicio de sesion','28/05/2016','10:28:40'),(47,2,'Inicio de sesion','29/05/2016','12:31:10'),(48,2,'Inicio de sesion','30/05/2016','09:01:08'),(49,2,'Cierre de sesion','30/05/2016','09:01:12'),(50,2,'Cierre de sesion','30/05/2016','09:01:12'),(51,2,'Inicio de sesion','30/05/2016','09:02:13'),(52,2,'Cierre de sesion','30/05/2016','09:28:42'),(53,2,'Inicio de sesion','30/05/2016','10:27:34'),(54,2,'Cierre de sesion','30/05/2016','10:27:38'),(55,2,'Inicio de sesion','30/05/2016','10:29:14'),(56,2,'Cierre de sesion','30/05/2016','10:31:16'),(57,2,'Cierre de sesion','30/05/2016','10:31:16'),(58,2,'Inicio de sesion','30/05/2016','10:31:21'),(59,2,'Cierre de sesion','30/05/2016','10:31:29'),(60,2,'Cierre de sesion','30/05/2016','10:31:29'),(61,2,'Inicio de sesion','30/05/2016','10:33:30'),(62,2,'Cierre de sesion','30/05/2016','10:33:34'),(63,2,'Cierre de sesion','30/05/2016','10:33:34'),(64,2,'Inicio de sesion','30/05/2016','10:36:26'),(65,2,'Cierre de sesion','30/05/2016','10:36:40'),(66,2,'Cierre de sesion','30/05/2016','10:36:40'),(67,2,'Inicio de sesion','30/05/2016','10:37:02'),(68,2,'Cierre de sesion','30/05/2016','10:37:06'),(69,2,'Cierre de sesion','30/05/2016','10:37:06'),(70,3,'Inicio de sesion','30/05/2016','10:37:11'),(71,3,'Cierre de sesion','30/05/2016','10:37:35'),(72,2,'Inicio de sesion','30/05/2016','10:49:15'),(73,2,'Cierre de sesion','30/05/2016','10:49:51'),(74,2,'Cierre de sesion','30/05/2016','10:49:51'),(75,2,'Inicio de sesion','30/05/2016','10:49:55'),(76,2,'Inicio de sesion','30/05/2016','10:50:08'),(77,2,'Inicio de sesion','30/05/2016','10:50:08'),(78,2,'Cierre de sesion','30/05/2016','10:50:15'),(79,2,'Cierre de sesion','30/05/2016','10:50:15'),(80,2,'Inicio de sesion','30/05/2016','10:52:53'),(81,2,'Inicio de sesion','30/05/2016','10:54:51'),(82,2,'Inicio de sesion','30/05/2016','10:54:51'),(83,2,'Cierre de sesion','30/05/2016','10:57:35'),(84,2,'Cierre de sesion','30/05/2016','10:57:35'),(85,2,'Inicio de sesion','30/05/2016','11:04:14'),(86,2,'Cierre de sesion','30/05/2016','11:05:07'),(87,2,'Cierre de sesion','30/05/2016','11:05:07'),(88,3,'Inicio de sesion','30/05/2016','11:09:32'),(89,3,'Cierre de sesion','30/05/2016','11:18:55'),(90,2,'Inicio de sesion','30/05/2016','11:20:58'),(91,2,'Cierre de sesion','30/05/2016','11:21:04'),(92,2,'Cierre de sesion','30/05/2016','11:21:04'),(93,3,'Inicio de sesion','30/05/2016','11:21:09'),(94,3,'Cierre de sesion','30/05/2016','11:30:18'),(95,2,'Inicio de sesion','30/05/2016','11:30:22'),(96,2,'Cierre de sesion','30/05/2016','11:31:09'),(97,2,'Cierre de sesion','30/05/2016','11:31:09'),(98,3,'Inicio de sesion','30/05/2016','11:31:13'),(99,2,'Inicio de sesion','31/05/2016','08:29:57'),(100,2,'Inicio de sesion','31/05/2016','08:54:12'),(101,2,'se modifico los permisos para el cargo Administrador','31/05/2016','08:54:23'),(102,2,'se modifico los permisos para el cargo Administrador','31/05/2016','08:54:23'),(103,2,'se modifico el area Desarrollo de saftwere','31/05/2016','08:56:31'),(104,2,'se modifico el area Desarrollo de saftwere','31/05/2016','08:56:31'),(105,2,'se modifico el area Desarrollo de saftwere','31/05/2016','08:56:39'),(106,2,'se modifico el area Desarrollo de saftwere','31/05/2016','08:56:39'),(107,2,'se agrego un nuevo area Recursos humanos','31/05/2016','09:04:54'),(108,2,'se agrego un nuevo area Recursos humanos','31/05/2016','09:04:54'),(109,2,'se agrego un nuevo area Ventas','31/05/2016','09:06:02'),(110,2,'se agrego un nuevo area Ventas','31/05/2016','09:06:02'),(111,2,'se agrego un nuevo cargo Supervisor de area','31/05/2016','09:06:48'),(112,2,'se agrego un nuevo cargo Supervisor de area','31/05/2016','09:06:48'),(113,2,'se agrego un nuevo cargo Emisor','31/05/2016','09:08:18'),(114,2,'se modifico los permisos para el cargo Administrador','31/05/2016','09:20:47'),(115,2,'se agrego un nuevo tipo documento PLAN','31/05/2016','09:21:22'),(116,2,'se agrego un nuevo tipo documento PERFIL','31/05/2016','09:21:39'),(117,2,'se modifico el tipo documento PRFL','31/05/2016','09:23:07'),(118,2,'Inicio de sesion','31/05/2016','04:34:44'),(119,2,'Cierre de sesion','31/05/2016','04:37:57'),(120,2,'Inicio de sesion','06/06/2016','11:24:35'),(121,2,'Cierre de sesion','06/06/2016','11:27:51'),(122,2,'Inicio de sesion','13/06/2016','05:39:47'),(123,2,'Cierre de sesion','13/06/2016','05:42:42'),(124,2,'Inicio de sesion','14/06/2016','09:08:29'),(125,2,'Cierre de sesion','14/06/2016','09:18:46'),(126,2,'Inicio de sesion','14/06/2016','09:55:29'),(127,2,'Cierre de sesion','14/06/2016','09:56:00'),(128,2,'Inicio de sesion','14/06/2016','09:56:04'),(129,2,'Cierre de sesion','14/06/2016','09:57:23'),(130,2,'Inicio de sesion','14/06/2016','10:10:26'),(131,2,'Cierre de sesion','14/06/2016','10:22:44'),(132,2,'Inicio de sesion','14/06/2016','08:51:35'),(133,2,'se agrego un nuevo cargo uno nuevo','14/06/2016','08:53:59'),(134,2,'Inicio de sesion','15/06/2016','10:21:24'),(135,2,'Cierre de sesion','15/06/2016','10:21:28'),(136,2,'Inicio de sesion','17/06/2016','08:47:01'),(137,2,'Cierre de sesion','17/06/2016','09:32:50'),(138,2,'Inicio de sesion','29/06/2016','10:54:03'),(139,2,'Inicio de sesion','29/06/2016','04:42:09'),(140,2,'Inicio de sesion','30/06/2016','03:46:57'),(141,2,'se modifico los permisos para el cargo Administrador','30/06/2016','05:20:10'),(142,2,'Cierre de sesion','30/06/2016','05:28:25'),(143,2,'Inicio de sesion','01/07/2016','04:02:21'),(144,2,'Inicio de sesion','02/07/2016','09:08:31'),(145,2,'Inicio de sesion','03/07/2016','03:12:32'),(146,2,'Inicio de sesion','04/07/2016','08:09:18'),(147,2,'Inicio de sesion','04/07/2016','05:15:29');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendario`
--

DROP TABLE IF EXISTS `calendario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendario` (
  `fecha` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendario`
--

LOCK TABLES `calendario` WRITE;
/*!40000 ALTER TABLE `calendario` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargo` (
  `pkcargo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `estado` int(11) DEFAULT '1',
  PRIMARY KEY (`pkcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'Administrador','Encargado de la administracion del sistema',1),(2,'Responsable de area','encargado de elaboracion de documentos',1),(3,'Supervisor de area','encargado de la revision de documentos elaborados',1),(6,'Emisor','encargado de emitir los documentos',1),(7,'uno nuevo','no',1);
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `pkmenu` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  PRIMARY KEY (`pkmenu`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Gestion documentos','fa fa-folder fa-fw fa-2x'),(2,'Configuracion','fa fa-cog fa-fw fa-2x'),(3,'Seguridad','fa fa-lock fa-fw fa-2x');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_detalle`
--

DROP TABLE IF EXISTS `menu_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_detalle` (
  `pkmenu_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `icono` varchar(50) NOT NULL,
  `controlador` varchar(30) NOT NULL,
  `fkmenu` int(11) NOT NULL,
  PRIMARY KEY (`pkmenu_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_detalle`
--

LOCK TABLES `menu_detalle` WRITE;
/*!40000 ALTER TABLE `menu_detalle` DISABLE KEYS */;
INSERT INTO `menu_detalle` VALUES (1,'Documento','fa fa-file fa-fw','documento',1),(2,'Plantilla','fa fa-file-text fa-fw','plantilla',1),(4,'Bitacora','fa fa-desktop fa-fw','bitacora',3),(5,'Usuario','fa fa-user fa-fw','usuario',3),(6,'Cargo','fa fa-briefcase fa-fw ','cargo',2),(7,'Permisos','fa fa-ban fa-fw','privilegio',3),(8,'Calendario','fa fa-calendar fa-fw','calendario',3),(9,'Archivos permitidos','fa fa-file-o fa-fw','archivo_config',3),(10,'Area','fa fa-sitemap fa-fw','area',2),(11,'Tipo documento','fa fa-cubes fa-fw','tipo_documento',2),(12,'Copia de seguridad','fa fa-database fa-fw','backup',3);
/*!40000 ALTER TABLE `menu_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilegio`
--

DROP TABLE IF EXISTS `privilegio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilegio` (
  `fkcargo` int(11) NOT NULL,
  `fkmenu_detalle` int(11) NOT NULL,
  PRIMARY KEY (`fkcargo`,`fkmenu_detalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilegio`
--

LOCK TABLES `privilegio` WRITE;
/*!40000 ALTER TABLE `privilegio` DISABLE KEYS */;
INSERT INTO `privilegio` VALUES (1,1),(1,2),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(2,1),(2,2);
/*!40000 ALTER TABLE `privilegio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_documento`
--

DROP TABLE IF EXISTS `tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_documento` (
  `pktipo_documento` int(11) NOT NULL AUTO_INCREMENT,
  `sigla` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pktipo_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_documento`
--

LOCK TABLES `tipo_documento` WRITE;
/*!40000 ALTER TABLE `tipo_documento` DISABLE KEYS */;
INSERT INTO `tipo_documento` VALUES (1,'PLAN','plan de negocio',1),(2,'PRFL','perfil de proyecto',1);
/*!40000 ALTER TABLE `tipo_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `pkusuario` int(11) NOT NULL AUTO_INCREMENT,
  `ci` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `archivo` varchar(30) NOT NULL,
  `fkcargo` int(11) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pkusuario`),
  KEY `fkcargo` (`fkcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (2,0,'luis daniel','admin@hotmail.com',78888777,'luis.crip',1,1),(3,1,'alejandro mollejas','alejandro@hotmail.com',123456,'alejandro.crip',2,1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-04 17:17:22
